#!/bin/bash

timestamp=$(date +%Y_%m_%d__%H_%M_%S__%p)
LOG_FILE=/etc/mccresourcecreation/collectmccdiagnostics_$timestamp.txt

DIAGNOSTIC_DIRECTORY="/etc/mccdiagnostics/"

exec > >(tee ${LOG_FILE}) 2>&1

CLEAR=`tput sgr0`
BOLD=`tput bold`
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
CYAN=`tput setaf 6 `
WHITE=`tput setaf 7 `

function printHeader
{
	echo -n "${CYAN}${BOLD}$1${CLEAR}"
}

function printDetail
{
	echo -e "\n${WHITE}${BOLD}$1${CLEAR}\n"
}

function printDetailGreen
{
	echo -e "\n${GREEN}${BOLD}$1${CLEAR}\n"
}

function printDetailMagenta
{
	echo -e "\n${MAGENTA}${BOLD}$1${CLEAR}\n"
}

function printWarning
{
	echo -e "\n${YELLOW}${BOLD}$1${CLEAR}\n"
}

function printError
{
	echo -e "\n${RED}${BOLD}$1${CLEAR}\n"
}
function cleanString
{
	s="$1"

	# remove leading and trailing whitespace
	s="$(echo -e "${s}" | tr -d '[:space:]')"

	# remove leading and trailing slashes
	s=`echo "${s}" | sed -e "s/\/*$//" `
	s=`echo "${s}" | sed -e "s/^\///" `
}

printHeader "Starting MCC Diagnostic Collection"

printDetailMagenta "Ensuring script is running as root"
# Ensure the script is running as sudo / rooot
if [ $(id -u) = "0" ];
then
	printDetailGreen "Running as root, collecting diagnostics"
else
	printError "Pleaes re-run script as root or start via sudo. Exiting"
	exit 1
fi

# Create a new folder under etc for output of necessary files
printDetailMagenta "Attempting to create new directory in etc for diagnostic file output"
if [ -d $DIAGNOSTIC_DIRECTORY ];
then
	printDetailGreen "MCC diagnostic directory already exists, continuing"
else
	mkdir $DIAGNOSTIC_DIRECTORY
	printDetailGreen "Created new directory mccdiagnostics in etc directory"
fi

# Get Disk Free output
printDetailMagenta "Capturing DF diagnostics"
df > $DIAGNOSTIC_DIRECTORY/dfoutput_$timestamp.txt
printDetailGreen "Completed capturing output from df"

# Get Top info
printDetailMagenta "Capturing current info from Top"
top -n 1 -b -E m > $DIAGNOSTIC_DIRECTORY/topoutput_$timestamp.txt
printDetailGreen "Completed capturing output from Top" 

# Get dmesg info
printDetailMagenta "Capturing dmesg info from host"
dmesg > $DIAGNOSTIC_DIRECTORY/dmesg_$timestamp.txt
printDetailGreen "Completed capturing dmesg info from host"

# Get lsof info
printDetailMagenta "Capturing current port info from lsof"
lsof -i :80 > $DIAGNOSTIC_DIRECTORY/lsofPortEighty_$timestamp.txt
lsof -i :443 > $DIAGNOSTIC_DIRECTORY/lsofPortFourFourThree_$timestamp.txt
lsof -i :43 > $DIAGNOSTIC_DIRECTORY/lsofPortFourThree_$timestamp.txt
lsof -i :53 > $DIAGNOSTIC_DIRECTORY/lsofPortFiveThree_$timestamp.txt
printDetailGreen "Completed capturing output from lsof"

# Get disk info from lsblk
printDetailMagenta "Capturing additional disk info from lsblk"
lsblk -o NAME,FSTYPE,SIZE,MOUNTPOINT,LABEL > $DIAGNOSTIC_DIRECTORY/lsblkoutput_$timestamp.txt
printDetailGreen "Completed capturing output from lsblk"

# Get IOT Edge List Info
printDetailMagenta "Capturing IoT diagnostics"
iotedge list > $DIAGNOSTIC_DIRECTORY/iotedgelist_$timestamp.txt

# Get zip file of iot edge diagnostics
iotedge support-bundle --since 12h --output $DIAGNOSTIC_DIRECTORY/iotedge_support_bundle_$timestamp.zip
printDetailGreen "Completed capturing IoT diagnostics"



# Get summary from local machine
printDetailMagenta "Getting MCC container id from docker"
containerId=$(docker container list | grep msconnectedcache | cut -d ' ' -f1)

if [ -z "$containerId" ];
then
	printWarning "Not able to find a running MCC container, skipping MCC container specific diagnostics"
else
	printDetailGreen "Found running MCC containerId : $containerId"
	printDetailMagenta "Proceeding with collecting MCC container diagnostics"

	printDetailMagenta "Collecting MCC summary from inside container"
	sudo docker exec $containerId  /bin/bash -c "wget -O /nginx/cache1/diagnostic_summary.json http://127.0.0.1:5000/summary"
	printDetailGreen "Successfully collected summary and saved to cache1 directory"

	# Get nginx logs
	printDetailMagenta "Collecting nginx logs from inside container"
	sudo docker cp $containerId:/nginx/logs $DIAGNOSTIC_DIRECTORY/nginx_logs
	printDetailGreen "Successfully collected nginx logs and saved to diagnostic folder"

	printDetailMagenta "Getting mapped cache1 directory to copy over diagnostic files"
	cacheOne=$(cat /etc/mccresourcecreation/CustomerInputs.txt | grep UserInputCacheLocation | cut -d ' ' -f1 | cut -d '=' -f2)
	sudo cp $cacheOne/diagnostic_summary.json $DIAGNOSTIC_DIRECTORY/diagnostic_summary.json
	printDetailGreen "Successfully found cache1 drive at $cacheOne and moved summary diagnostic json"

	# Get charts from nginx/cache1
	printDetailMagenta "Moving saved MCC chart data from cache1 directory"
	find $cacheOne -type f | grep -i Chart* | sudo xargs -i cp {} $DIAGNOSTIC_DIRECTORY/
	printDetailGreen "Successfully moved chart data from MCC cache drive to diagnostic folder"
fi

# Copy over MCC install logs
printDetailMagenta "Copy over resource install logs"
cp -r /etc/mccresourcecreation/* $DIAGNOSTIC_DIRECTORY/
printDetailGreen "Successfully copied over MCC resource install logs"

# Zip the package to be uploaded
printDetailMagenta "Compressing diagnostic directory for sending"
cd $DIAGNOSTIC_DIRECTORY/
tar czvf support_bundle_$timestamp.tar.gz * --remove-files
printDetailGreen "Successfully zipped package , please send file created at /etc/mccdiagnostics/support_bundle_$timestamp.tar.gz"
