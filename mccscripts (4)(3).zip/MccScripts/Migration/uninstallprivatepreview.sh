#!/bin/bash
CLEAR=`tput sgr0`
BOLD=`tput bold`
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
CYAN=`tput setaf 6 `
WHITE=`tput setaf 7 `

function printHeader
{
	echo -n "${CYAN}${BOLD}$1${CLEAR}"
}

function printDetail
{
	echo -e "\n${WHITE}${BOLD}$1${CLEAR}\n"
}

function printDetailGreen
{
	echo -e "\n${GREEN}${BOLD}$1${CLEAR}\n"
}

function printDetailMagenta
{
	echo -e "\n${MAGENTA}${BOLD}$1${CLEAR}\n"
}

function printWarning
{
	echo -e "\n${YELLOW}${BOLD}$1${CLEAR}\n"
}

function printError
{
	echo -e "\n${RED}${BOLD}$1${CLEAR}\n"
}

function cleanString
{
	s="$1"
	
	# remove leading and trailing whitespace
	s="$(echo -e "${s}" | tr -d '[:space:]')"
	
	# remove leading and trailing slashes
	s=`echo "${s}" | sed -e "s/\/*$//" `
	s=`echo "${s}" | sed -e "s/^\///" `	
}

containerCount=0
printDetailMagenta "Validating no containers other than MCC and dependencies currently exist"
while read -r line; do ((containerCount+=1)); done < <(sudo docker ps -a);

if [ $containerCount -gt 4 ]; then
	printWarning "Are you sure you wish to proceed? Detected additional docker conatiners on this machine that may be affected if MCC uninstall continues : [Y/n]"
	read -r UserProceedWithAdditionalContainers
	cleanString ${UserProceedWithAdditionalContainers}
	
	if [ -z $UserProceedWithAdditionalContainers ] || [ $UserProceedWithAdditionalContainers == "y" ] || [ $UserProceedWithAdditionalContainers == "Y" ]; then
		printDetailGreen "Proceeding with steps for uinstalling MCC"
	elif [ $UserProceedWithAdditionalContainers == "n" ] || [ $UserProceedWithAdditionalContainers == "N" ]; then
		printError "Not proceeding with steps for uinstalling MCC. Exiting"
		exit 1
	else
		printError "Invalid input entered, please re-run script with valid input. Exiting"
		exit 1
	fi
else
	printDetailGreen "Validated that only MCC container and dependencies exist on machine"
fi

# remove iot edge and config files
printDetailMagenta "Uninstalling IoT Edge and associated config files"
apt-get -y remove iotedge --purge 

printDetailGreen "Successfully uninstalled IoT Edge and removed config files"

printDetailMagenta "Checking to see if docker is installed and if there are any running conatiners"
if ! docker ps -a
then
	printDetailGreen "Docker is not instaled or no running conatiners were detected"
else
	# remove all related conatiners
	printDetailMagenta "Stopping all MCC related docker conatiners, if they exist"
	docker stop edgeAgent
	docker stop edgeHub
	docker stop MCC 
	printDetailGreen "Stopped running conatiners or no MCC related containers to stop"

	printDetailMagenta "Attempting to remove all MCC related docker conatiners"
	docker rm -f MCC
	docker rm -f edgeAgent
	docker rm -f edgeHub
	printDetailGreen "Successfully removed MCC related docker conatiners or no MCC related conatiners to stop" 

fi

# remove container run times and associated files
printDetailMagenta "Uninstalling container runtimes"
apt-get -y remove --purge moby-cli
apt-get -y remove --purge moby-engine
printDetailGreen "Successfully uinstalled container runtimes"

printDetailGreen "Successfully ran MCC uninstall script for private preview"