#!/bin/bash
ScriptVersion=1.00
DefaultMccLocation=westus
EdgeAgent='$edgeAgent'
MigrationTag="Source=MCCMigrationScript"
Https=https://
ToolName="/tool?toolName=doinc&"
MigrationToolName="/tool?toolName=migration&"
ApiVersion=2022-03-21-preview

declare -a DrivePathArray
declare -a DriveSizeArray

timestamp=$(date +%Y_%m_%d__%H_%M_%S__%p)
LOG_FILE=/etc/mccresourcecreation/migrationForConnectedCacheLog_$timestamp.txt

exec > >(tee ${LOG_FILE}) 2>&1

# set -e

CLEAR=`tput sgr0`
BOLD=`tput bold`
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
CYAN=`tput setaf 6 `
WHITE=`tput setaf 7 `

function printHeader
{
        echo -n "${CYAN}${BOLD}$1${CLEAR}"
}

function printDetail
{
        echo -e "\n${WHITE}${BOLD}$1${CLEAR}\n"
}

function printDetailGreen
{
        echo -e "\n${GREEN}${BOLD}$1${CLEAR}\n"
}

function printDetailMagenta
{
        echo -e "\n${MAGENTA}${BOLD}$1${CLEAR}\n"
}

function printWarning
{
        echo -e "\n${YELLOW}${BOLD}$1${CLEAR}\n"
}

function printError
{
        echo -e "\n${RED}${BOLD}$1${CLEAR}\n"
}
function cleanString
{
        s="$1"

        # remove leading and trailing whitespace
        s="$(echo -e "${s}" | tr -d '[:space:]')"

        # remove leading and trailing slashes
        s=`echo "${s}" | sed -e "s/\/*$//" `
        s=`echo "${s}" | sed -e "s/^\///" `
}

function isProvisioningSucceeded
{
        Response=$(az resource show --ids "$1" 2>null)

        if [ $? != 0 ] && [ $2 == false ]
        then
                return 0
        else
                count=0
                provisioningState=""
                while [[ $provisioningState != Succeeded ]]
                do
                        if [[ $provisioningState == Failed ]]
                        then
                                return 2
                        elif [[ $count == 30 ]]
                        then
                                printError "Provisioning state for the resource is not succeeded, exiting"
                                exit 1
                        fi

                        sleep 5
                        Response=$(az resource show --ids "$1" 2>null)
                        provisioningState=$(echo $Response | sed 's#\(.*"provisioningState": "\)\([^"]*\)\(.*\)#\2#')
                        ((count++))
                done
        fi
        return 1
}

printHeader "Micorsoft Connected Cache Migration to Public Preview Script, Version : $ScriptVersion"
echo -e "\n"

printDetailMagenta "Checking for the existence of MCC directory"
if [ -d "/etc/mccresourcecreation/" ];
then
        printDetailGreen "MCC directory already exists, continuing"
else
        printDetailMagenta "MCC directory not detected, creating"
        mkdir /etc/mccresourcecreation/
        printDetailGreen "MCC directory successfully created"
fi

printDetailMagenta "Checking to ensure that Ubuntu version is 20.04"

UbuntuVersion=$(lsb_release -r | cut -d ':' -f2 | tr -d '[:space:]')

if [[ $UbuntuVersion == 20.04 ]]
then
        printDetailGreen "Successfully verified that Ubuntu version is 20.04. Continuing with migration."
else
        printError "Current ubuntu version is $UbuntuVersion which is different from the recommended 20.04 version. Exiting."
        exit 1
fi

# Read input parameters from the command line and set relevant variables
for ARGUMENT in "$@"
do

        KEY=$(echo $ARGUMENT | cut -f1 -d=)
        VALUE=$(echo $ARGUMENT | cut -f2 -d=)

        cleanString "${KEY}"
        KEY="${s}"
        cleanString "${VALUE}"
        VALUE="${s}"

        case "$KEY" in
                customerid)                                     CommandLineCustomerId=${VALUE} ;;
                tenantid)                                       CommandLineTenantId=${VALUE};;
                customerasn)                                    CommandLineCustomerAsn=${VALUE};;
                transitasn)                                     CommandLineTransitAsn=${VALUE};;
                transitstate)                                   CommandLineTransitState=${VALUE};;
                *)                      ;;
        esac
done

if [ -z $CommandLineCustomerId ]; then
        printError "Azure Customer ID cannot be null, please ensure proper command line arguments are used, exiting "
        exit 1
fi

if [ -z $CommandLineTenantId ]; then
        printError "Tenant Id cannot be null, please ensure proper command line arguments are used, exiting"
        exit 1
fi

CustTransitState=0
CustTransitAsn=""

RedactCommandLineCustomerId=`echo "${CommandLineCustomerId}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
RedactCommandLineTenantId=`echo "${CommandLineTenantId}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`

printDetailMagenta "Querying Microsoft Connected Cache container for config details"

UseLocalContainerConfig=true

MccContainerId=$(docker ps -aqf "name=^MCC$")

if [[ $? == 0 ]] && [[ ! -z $MccContainerId ]]; then

        MCCModuleInfo=$(docker inspect $MccContainerId)

        if [[ $? == 0 ]] && [[ ! -z $MCCModuleInfo ]]; then

                MCCModuleInfo=$(echo $MCCModuleInfo | sed 's|\"|#|g')
                MCCModuleInfo=$(echo $MCCModuleInfo | sed 's|\]|@|g')

                CustomerIdOutput=$(echo $MCCModuleInfo | grep CUSTOMER_ID)
                CustomerKeyOutput=$(echo $MCCModuleInfo | grep CUSTOMER_KEY)
                CacheNodeIdOutput=$(echo $MCCModuleInfo | grep CACHE_NODE_ID)

                if [[ -z $CustomerIdOutput ]] || [[ -z $CustomerKeyOutput ]] || [[ -z $CacheNodeIdOutput ]]; then
                        printWarning "Unable to find customer and cache node ids in Microsoft Connected Cache container. Proceeding to query for config from IoTHub"
                        UseLocalContainerConfig=false
                else
                        CustomerId=$(echo $MCCModuleInfo | sed 's|\(\[.*#CUSTOMER_ID=\)\([^#]*\)\(#.*\)|\2|g')
                        CustomerKey=$(echo $MCCModuleInfo | sed 's|\(\[.*#CUSTOMER_KEY=\)\([^#]*\)\(#.*\)|\2|g')
                        CacheNodeId=$(echo $MCCModuleInfo | sed 's|\(\[.*#CACHE_NODE_ID=\)\([^#]*\)\(#.*\)|\2|g')

                        if [[ -z $CustomerId ]] || [[ -z $CustomerKey ]] || [[ -z $CacheNodeId ]]; then
                                printWarning "Unable to find customer and cache node ids in Microsoft Connected Cache container. Proceeding to query for config from IoTHub"
                                UseLocalContainerConfig=false
                        else
                                printDetailMagenta "Gathering drive and bgp info. Please wait"

                                if [[ $MCCModuleInfo == *"BGP_NEIGHBORS"* ]]; then
                                        BgpInfo=$(echo $MCCModuleInfo | sed 's|\(\[.*#BGP_NEIGHBORS=\)\([^#]*\)\(#.*\)|\2|g')
                                        if [[ ! -z $BgpInfo ]] ; then
                                                BgpInfo=\"${BgpInfo}\"
                                        fi
                                fi

                                DriveInfoPresent=false

                                for ((i=1; i<=10; i++))
                                do
                                        if [[ $MCCModuleInfo == *"STORAGE_${i}_SIZE_GB"* ]]; then
                                                IndexedDrivePath=$(echo $MCCModuleInfo | sed 's|\(\[.*#Binds#: \[\)\([^@]*\)\(@.*\)|\2|g' | tr -d '[:space:]' | cut -d "," -f $i | sed 's|#||g')
                                                DrivePath=$(echo $IndexedDrivePath | cut -d ":" -f 1)
                                                DrivePathArray+=("$DrivePath")

                                                StorageSizeIndex="STORAGE_${i}_SIZE_GB"
                                                DriveSize=$(echo $MCCModuleInfo | sed 's|\(\[.*#'"$StorageSizeIndex"'=\)\([^#]*\)\(#.*\)|\2|g')
                                                DriveSizeArray+=("$DriveSize")

                                                DriveInfoPresent=true
                                        else
                                                break
                                        fi
                                done

                                if [[ "$DriveInfoPresent" = false ]] ; then
                                        printWarning "Unable to find drive info in Microsoft Connected Cache container. Proceeding to query for config from IoTHub"
                                        UseLocalContainerConfig=false
                                else
                                        printDetailGreen "Successfully obtained drive and bgp info"
                                fi                        
                        fi
                fi
        else
                printWarning "Unable to find Microsoft Connected Cache container. Proceeding to query for config from IoTHub"
                UseLocalContainerConfig=false
        fi
else
        printWarning "Unable to find Microsoft Connected Cache container id. Proceeding to query for config from IoTHub"
        UseLocalContainerConfig=false
fi

printDetailMagenta "Querying iotedge config for device details"
ConnectionStringDeviceName=$(cat /etc/iotedge/config.yaml | grep "device_connection_string" | grep ":" | cut -d ":" -f2)
if [[ ! -e "/etc/iotedge/config.yaml" ]] || [[ $ConnectionStringDeviceName == *"ADD DEVICE CONNECTION STRING HERE"* ]]; then
        printError "Device has not previously been connected to an IoT Hub, exiting"
        exit 1
else
        IotHubName=$(echo $ConnectionStringDeviceName | cut -d ";" -f1 | cut -d "=" -f2 | cut -d "." -f1)
        IotDeviceName=$(echo $ConnectionStringDeviceName | cut -d ";" -f2 | cut -d "=" -f2)
        printDetailGreen "Successfully obtained device details"
fi

printDetailMagenta "Installing Azure CLI"
apt-get install -y curl
if ! curl -sL https://aka.ms/InstallAzureCLIDeb | bash
then
        printError "Unable to install Azure CLI, exiting"
        exit 1
fi
printDetailGreen "Completed installing Azure CLI"

printDetailMagenta "Logging in to azure portal with device code"
if ! az login --use-device-code --tenant ${CommandLineTenantId}
then
        printError "Unable to log in to azure portal, exiting"
        exit 1
fi
printDetailGreen "Successfully logged in to azure portal using tenant id : ${RedactCommandLineTenantId}"

# Before any azure operations, ensure that we have set proper subscription
printDetailMagenta "Attempting to set specificied subscription id for resource creation"
if ! SetCustomerSubscrption=$(az account set --subscription ${CommandLineCustomerId});
then
        printError "Unable to use specified subscription for Microsoft Connected Cache public preview resource creation, please try again. Exiting"
        exit 1;
else
        printDetailGreen "Successfully set subscription, proceeding using subscription : $RedactCommandLineCustomerId"
fi

printDetailMagenta "Installing the latest version of Azure IoT Edge extension"
if ! az extension add --upgrade -n azure-iot
then
        printError "Unable to install Azure IoT Edge extension"
        exit 1
else
        printDetailGreen "Successfully installed Azure IoT Edge extension"
fi

if [[ "$UseLocalContainerConfig" = false ]] ; then
        printDetailMagenta "Querying IoTHub for config details"
        MCCModuleInfo=$(az iot hub module-twin show -d ${IotDeviceName} --hub-name ${IotHubName} -m ${EdgeAgent} --query 'properties.desired.modules.MCC')

        if [[ ! -z $MCCModuleInfo ]]; then
                MCCModuleInfo=$(echo $MCCModuleInfo | sed 's|\}|@|g')
                MCCModuleInfo=$(echo $MCCModuleInfo | sed 's|\]|#|g')
                CustomerId=$(echo $MCCModuleInfo | sed 's|\({.*"CUSTOMER_ID": { "value": \)\([^@]*\)\(.*\)|\2|g' | sed 's/"//g' | tr -d '[:space:]')
                CustomerKey=$(echo $MCCModuleInfo | sed 's|\({.*"CUSTOMER_KEY": { "value": \)\([^@]*\)\(.*\)|\2|g' | sed 's/"//g' | tr -d '[:space:]')
                CacheNodeId=$(echo $MCCModuleInfo | sed 's|\({.*"CACHE_NODE_ID": { "value": \)\([^@]*\)\(.*\)|\2|g' | sed 's/"//g' | tr -d '[:space:]')

                if [ -z $CustomerId ] || [ -z $CustomerKey ] || [ -z $CacheNodeId ]; then
                        printError "Unable to retrieve cache node details, please try again. Exiting"
                        exit 1
                fi
        else
                printError "Unable to retrieve cache node details, please try again. Exiting"
                exit 1
        fi

        printDetailMagenta "Gathering drive and bgp info. Please wait"

        if [[ $MCCModuleInfo == *"BGP_NEIGHBORS"* ]]; then
                BgpInfo=$(echo $MCCModuleInfo | sed 's|\({.*"BGP_NEIGHBORS": { "value": \)\([^@]*\)\(.*\)|\2|g')
        fi

        for ((i=1; i<=10; i++))
        do
                if [[ $MCCModuleInfo == *"STORAGE_${i}_SIZE_GB"* ]]; then
                        IndexedDrivePath=$(echo $MCCModuleInfo | sed 's|\({.*\\\"Binds\\\":\[\)\([^#]*\)\(.*\)|\2|g' | cut -d "," -f $i)
                        DrivePath=$(echo $IndexedDrivePath | cut -d ":" -f 1 | sed 's/\\\"//g')
                        DrivePathArray+=("$DrivePath")
                else
                        break
                fi

                StorageSizeIndex="\"STORAGE_${i}_SIZE_GB\""
                DriveSize=$(echo $MCCModuleInfo | sed 's|\({.*'"$StorageSizeIndex"': { "value": \)\([^@]*\)\(.*\)|\2|g')
                DriveSizeArray+=("$DriveSize")
        done
        printDetailGreen "Successfully obtained drive and bgp info"
fi

printDetailMagenta "Validating device details"

printDetailMagenta "Calling to retrieve latest values for running Microsoft Connected Cache resource migration script"
GeoResponse=$(curl --insecure -i 'https://geomcc.prod.do.dsp.mp.microsoft.com/geo')
KvEndpointUrl=$( echo $GeoResponse | grep -Po '"KeyValue_EndpointFullUri":.*?[^\\]",' | tr "," "\n"  | cut -d "\"" -f4 | cut -d "/" -f3)
printDetailGreen "Successfully retrieved latest values for Microsoft Connected Cache resource migration"

QueryCustomerKey="doincCustomerKey=${CustomerKey}"
QueryCustomerId="&doincCustomerId=${CustomerId}"
QueryCacheNodeId="&doincCacheNodeId=${CacheNodeId}"

FinalKvToolUri="${Https}${KvEndpointUrl}${ToolName}${QueryCustomerKey}${QueryCustomerId}${QueryCacheNodeId}"
KvDoincToolResponse=$(curl -s -i ${FinalKvToolUri})
IsValidCustomer=$(echo $KvDoincToolResponse | grep -Po '"IsValidCustomer":.*?[^\\]"' | cut -d '"' -f4)

if [ "$IsValidCustomer" == "false" ];
        then
        RedactedCustomerId=`echo "${CustomerId}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
        RedactedCustomerKey=`echo "${CustomerKey}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
        RedactedCacheNodeId=`echo "${CacheNodeId}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
        printError "The customer Id, cusotmer key and cache node Id are either invalid or not entitled. Please verify that the cusotmer Id, key and cache node id match the values in the portal \n
        CustomerId:\t\t ${RedactedCustomerId} \n
        CustomerKey:\t\t ${RedactedCustomerKey} \n
        CacheNodeId:\t\t ${RedactedCacheNodeId} \n Exiting"
        exit 1
fi
printDetailGreen "Successfully completed device validation"

printDetailMagenta "Acquiring resource group and Microsoft Connected Cache resource name if already migrated"

MigrationToolUri="${Https}${KvEndpointUrl}${MigrationToolName}${QueryCustomerKey}${QueryCustomerId}${QueryCacheNodeId}"
MigrationToolResponse=$(curl -s -i ${MigrationToolUri})
Fqrid=$(echo $MigrationToolResponse | grep -Po '"Fqrid":.*?[^\\]"' | cut -d '"' -f4)
CustomerReleaseVersion=$(echo $MigrationToolResponse | grep -Po '"CustomerReleaseVersion":.*?[^\\]"' | cut -d '"' -f4)

if [[ "$CustomerReleaseVersion" == "2" && "$Fqrid" == *"/ispCustomers/"* ]];
then
        MccResourceGroupName=$(echo $Fqrid | cut -d '/' -f5)
        CustomerName=$(echo $Fqrid | cut -d '/' -f9)

        printDetailGreen "Microsoft Connected Cache resource already migrated. Resource group: $MccResourceGroupName, Microsoft Connected Cache resource: $CustomerName"
else
        printDetailMagenta "Microsoft Connected Cache resource not migrated. Continuing with migration"

        ResourceGroupReadRetry=2

        while [[ $ResourceGroupReadRetry != 0 ]]
        do
                ((ResourceGroupReadRetry--))
                printHeader "Please enter existing or new resource group name to be used for creating Microsoft Connected Cache public preview resources : "
                read MccResourceGroupName
                cleanString ${MccResourceGroupName}

                if [[ -z $MccResourceGroupName && $ResourceGroupReadRetry == 0 ]]; then
                        printError "Resource group name cannot be null, please ensure proper input is entered, exiting "
                        exit 1
                elif [[ -z $MccResourceGroupName ]]; then
                        printWarning "Resource group name cannot be null, retrying again"
                else
                        break
                fi
        done

        if [ $(az group exists --name $MccResourceGroupName) = false ]
        then
                printDetailMagenta "$MccResourceGroupName resource group not found, creating one."

                if ! NewRgDetails=$(az group create --name ${MccResourceGroupName} --location ${DefaultMccLocation})
                then
                        printError "Unable to create resource group, exiting"
                        exit 1
                else
                        printDetailGreen "Successfully created new resource group for MCC resources"
                        printDetailMagenta "Attempting to update resource group with $MigrationTag tag"
                        ResourceGroupId=$(echo $NewRgDetails | grep -Po '"id":.*?[^\\]",' | cut -d '"' -f4)
                        az tag create --resource-id $ResourceGroupId --tags $MigrationTag
                        printDetailGreen "Successfully added tags to new resource group"
                fi
        else
                printDetailGreen "$MccResourceGroupName resource group already exists. Continuing with migration."
        fi

        MccReadRetry=2

        while [[ $MccReadRetry != 0 ]]
        do
                ((MccReadRetry--))
                printHeader "Please provide a name for the public preview Microsoft Connected Cache resource that will contain your cache nodes. Enter alphanumeric values and underscores only (A-Z,a-z,0-9,_) : "
                read CustomerName
                cleanString ${CustomerName}

                if [[ -z $CustomerName && $MccReadRetry == 0 ]]; then
                        printError "Public preview connected cache resource name cannot be null, please ensure proper input is entered, exiting "
                        exit 1
                elif [[ -z $CustomerName ]]; then
                        printWarning "Public preview connected cache resource name cannot be null, retrying again"
                else
                        break
                fi
        done

        CustomerName+="_v2"
fi

AccessToken=$(az account get-access-token --query accessToken | tr '"' ' ')

CurrentCloud=$(az cloud show)

ResourceManager=$(echo $CurrentCloud | grep -Po '"resourceManager":.*?[^\\]",' | tr "," "\n"  | cut -d "\"" -f4)

if [[ $ResourceManager == */ ]]
then
        ResourceManager=$(echo $ResourceManager | sed 's/.$//')
fi

CustomerResourceUrl=$ResourceManager/subscriptions/$CommandLineCustomerId/resourceGroups/$MccResourceGroupName/providers/Microsoft.ConnectedCache/ispCustomers/$CustomerName?api-version=$ApiVersion
CacheNodeResourceUrl=$ResourceManager/subscriptions/$CommandLineCustomerId/resourceGroups/$MccResourceGroupName/providers/Microsoft.ConnectedCache/ispCustomers/$CustomerName/ispCacheNodes/$IotDeviceName?api-version=$ApiVersion

FqdrCustomerResourceUrl=/subscriptions/$CommandLineCustomerId/resourceGroups/$MccResourceGroupName/providers/Microsoft.ConnectedCache/ispCustomers/$CustomerName?api-version=$ApiVersion
FqdrCacheNodeResourceUrl=/subscriptions/$CommandLineCustomerId/resourceGroups/$MccResourceGroupName/providers/Microsoft.ConnectedCache/ispCustomers/$CustomerName/ispCacheNodes/$IotDeviceName?api-version=$ApiVersion

printDetailMagenta "Verifying public preview Microsoft Connected Cache resource $CustomerName's migration status"

isProvisioningSucceeded $FqdrCustomerResourceUrl false

if [[ $? == 1 ]]
then
        printDetailGreen "Verified Microsoft Connected Cache resource $CustomerName migration. Proceeding with cache node migration"
else
        printDetailMagenta "Microsoft Connected Cache resource $CustomerName does not exist. Proceeding with migration"

        if [ -z $CommandLineCustomerAsn ] || ! [[ $CommandLineCustomerAsn =~ ^[0-9]+$ ]] || ! (([ $CommandLineCustomerAsn -ge 1 ] && [ $CommandLineCustomerAsn -le 64495 ]) || ([ $CommandLineCustomerAsn -ge 131972 ] && [ $CommandLineCustomerAsn -le 401308 ])); then
                printHeader "Please enter the numeric portion of your organization's ASN. The number should be between 1 - 64495 or 131972 - 401308 : "
                read UserInputCustomerAsn
                cleanString ${UserInputCustomerAsn}

                if [ -z $UserInputCustomerAsn ]; then
                        printError "ASN cannot be null, please ensure proper input is entered, exiting"
                        exit 1
                elif ! [[ $UserInputCustomerAsn =~ ^[0-9]+$ ]] || ! (([ $UserInputCustomerAsn -ge 1 ] && [ $UserInputCustomerAsn -le 64495 ]) || ([ $UserInputCustomerAsn -ge 131972 ] && [ $UserInputCustomerAsn -le 401308 ])); then
                        printError "ASN should be the numeric portion of your organization's ASN. The number should be between 1 - 64495 or 131972 - 401308, please ensure proper input is entered, exiting"
                        exit 1
                fi
                CustAsn=$UserInputCustomerAsn
        else
                CustAsn=$CommandLineCustomerAsn
        fi

        CustomerMigrationMaxRetry=3

        while [[ $CustomerMigrationMaxRetry != 0 ]]
        do
                ((CustomerMigrationMaxRetry--))

                if [ -z $CustTransitAsn ]; then
                        CreateCustomerResponse=$(curl -s -k -i -X PUT "$CustomerResourceUrl&customerId=$CommandLineCustomerId&shouldMigrate=True&customerTransitState=$CustTransitState&customerAsn=$CustAsn" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken"  -d '{ "location":"westus", "properties": { "customer": { "CustomerId": '\"$CommandLineCustomerId\"' }}}' | grep HTTP/2 | sed 's#HTTP/2 ##g' | tr -d '[:space:]')
                else
                        CreateCustomerResponse=$(curl -s -k -i -X PUT "$CustomerResourceUrl&customerId=$CommandLineCustomerId&shouldMigrate=True&customerTransitState=$CustTransitState&customerTransitAsn=$CustTransitAsn&customerAsn=$CustAsn" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken"  -d '{ "location":"westus", "properties": { "customer": { "CustomerId": '\"$CommandLineCustomerId\"' }}}' | grep HTTP/2 | sed 's#HTTP/2 ##g' | tr -d '[:space:]')
                fi

                sleep 10

                if [[ $CreateCustomerResponse == 2** ]]
                then
                        isProvisioningSucceeded $FqdrCustomerResourceUrl true

                        if [[ $? == 1 ]]
                        then
                                printDetailGreen "Successfully migrated Microsoft Connected Cache resource $CustomerName"
                                break
                        elif [[ $? == 2 && $CustomerMigrationMaxRetry != 0 ]]
                        then
                                printWarning "Microsoft Connected Cache resource provision state failed, retrying again"
                        else
                                printError "Unable to migrate Microsoft Connected Cache resource $CustomerName. Please contact Microsoft, exiting"
                                exit 1
                        fi
                elif [[ $CustomerMigrationMaxRetry == 0 ]]
                then
                        printError "Unable to migrate Microsoft Connected Cache resource $CustomerName. Please make sure you have resource create permission under $MccResourceGroupName resource group, exiting"
                        exit 1
                fi
        done
fi

printDetailMagenta "Checking cache node $IotDeviceName's migration status"

sleep 10

isProvisioningSucceeded $FqdrCacheNodeResourceUrl false

if [[ $? == 1 ]]
then
        printDetailGreen "Cachenode $IotDeviceName has already been migrated, Proceeding with installation"
else
        printDetailMagenta "Cachenode $IotDeviceName does not exist. Proceeding with cache node migration"

        CacheNodeMigrationMaxRetry=3

        while [[ $CacheNodeMigrationMaxRetry != 0 ]]
        do
                ((CacheNodeMigrationMaxRetry--))

                CreateCacheNodeResponse=$(curl -s -k -i -X PUT "$CacheNodeResourceUrl&customerId=$CommandLineCustomerId&cacheNodeId=$CacheNodeId&cacheNodeName=$IotDeviceName&maxAllowableEgressInMbps=10000&isEnabled=True&isEnterprise=False&shouldMigrate=True" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken" -d '{ "location":"westus", "properties": { "additionalCacheNodeProperties": {}}}' | grep HTTP/2 | sed 's#HTTP/2 ##g' | tr -d '[:space:]')

                sleep 10

                if [[ $CreateCacheNodeResponse == 2** ]]
                then
                        isProvisioningSucceeded $FqdrCacheNodeResourceUrl true

                        if [[ $? == 1 ]]
                        then
                                printDetailGreen "Successfully created cache node $IotDeviceName"
                                break
                        elif [[ $? == 2 && $CacheNodeMigrationMaxRetry != 0 ]]
                        then
                                printWarning "Cache node resource provision state failed, retrying again"
                        else
                                printError "Unable to migrate Cache node resource $IotDeviceName. Please contact Microsoft, exiting"
                                exit 1
                        fi
                elif [[ $CacheNodeMigrationMaxRetry == 0 ]]
                then
                        printError "Unable to migrate Cache node resource $IotDeviceName. Please contact Microsoft, exiting"
                        exit 1
                fi
        done
fi

printDetailMagenta "Constructing request body for cache node migration. Please wait"

sleep 10

FirstPathEntry=true
RequestBody="{ \"location\": \"westus\", \"properties\": { \"additionalCacheNodeProperties\": { "

for index in "${!DrivePathArray[@]}"
do
        if [[ "$FirstPathEntry" = false ]] ; then
                RequestBody+=","
        else
                RequestBody+="\"driveConfiguration\": ["    
        fi

        RequestBody+=" { \"cacheNumber\": \"$((index+1))\", \"physicalPath\": \"${DrivePathArray[$index]}\", \"sizeInGb\": ${DriveSizeArray[$index]} }"
        FirstPathEntry=false
done

if [[ "$FirstPathEntry" = false ]] ; then
        RequestBody+="]";
fi

if [[ -z $BgpInfo ]] ; then
        RequestBody+="}}}";
elif [[ "$FirstPathEntry" = false ]] ; then
        RequestBody+=", \"bgpConfiguration\": {\"AsnToIpAddressMapping\": $BgpInfo }}}}";
else
        RequestBody+="\"bgpConfiguration\": {\"AsnToIpAddressMapping\": $BgpInfo }}}}";
fi
printDetailGreen "Successfully constructed request body for cache node migration"

CacheNodeGetMaxRetry=3

while [[ $CacheNodeGetMaxRetry != 0 ]]
do
        ((CacheNodeGetMaxRetry--))

        printDetailMagenta "Querying private preview cache node more details"
        CacheNodeBody=$(curl -s -k -i GET "$CacheNodeResourceUrl&customerId=$CommandLineCustomerId&cacheNodeId=$CacheNodeId&cacheNodeName=$IotDeviceName&maxAllowableEgressInMbps=10000&isEnabled=True&isEnterprise=False&shouldMigrate=True" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken")
        ResCacheNodeId=$(echo $CacheNodeBody | grep -Po '"CacheNodeId":.*?[^\\]",' | cut -d "\"" -f4)
        ResCacheNodeName=$(echo $CacheNodeBody | grep -Po '"CacheNodeName":.*?[^\\]",' | cut -d "\"" -f4)
        ResCustomerName=$(echo $CacheNodeBody | grep -Po '"CustomerName":.*?[^\\]",' | cut -d "\"" -f4)
        ResCustomerId=$(echo $CacheNodeBody | grep -Po '"CustomerId":.*?[^\\]",' | cut -d "\"" -f4)
        ResCidrCsv=$(echo $CacheNodeBody | grep -Po '"CidrCsv":.*?[^\\]",' | cut -d "\"" -f4 | sed -e 's# #%20#g')
        ResIpAddress=$(echo $CacheNodeBody | grep -Po '"IpAddress":.*?[^\\]",' | cut -d "\"" -f4)
        ResMaxAllowableEgressInMbps=$(echo $CacheNodeBody | grep -Po '"MaxAllowableEgressInMbps":.*?[^\\],' | tr "," "\n" | cut -d ":" -f2)
        ResIsEnabled=$(echo $CacheNodeBody | grep -Po '"IsEnabled":.*?[^\\],' | tr "," "\n"  | cut -d ":" -f2)
        ResIsEnterpriseManaged=$(echo $CacheNodeBody | grep -Po '"IsEnterpriseManaged":.*?[^\\],' | tr "," "\n"  | cut -d ":" -f2)
        ResCidrSelectionType=$(echo $CacheNodeBody | grep -Po '"CidrSelectionType":.*?[^\\],' | tr "," "\n"  | cut -d ":" -f2)

        if [[ -z $ResCidrSelectionType ]]; then
                ResCidrSelectionType=1
        fi

        if [[ ! -z $ResCacheNodeId ]]
        then
                printDetailGreen "Successfully obtained cache node details for migration"
                break
        elif [[ $CacheNodeGetMaxRetry == 0 ]]
        then
                printError "Unable to obtain cache node details, exiting"
                exit 1
        else
                printWarning "Unable to obtain cache node details, retrying again"
        fi
done

CacheNodeUpdateMaxRetry=3

while [[ $CacheNodeUpdateMaxRetry != 0 ]]
do
        ((CacheNodeUpdateMaxRetry--))
        
        UpdateCacheNodeResponse=$(curl -s -k -i -X PUT "$CacheNodeResourceUrl&customerId=$CommandLineCustomerId&cacheNodeId=$CacheNodeId&cacheNodeName=$IotDeviceName&customerName=$ResCustomerName&cidrCsv=$ResCidrCsv&maxAllowableEgressInMbps=$ResMaxAllowableEgressInMbps&ipAddress=$ResIpAddress&isEnabled=$ResIsEnabled&isEnterprise=$ResIsEnterpriseManaged&cidrSelectionType=$ResCidrSelectionType" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken" -d "$RequestBody" | grep HTTP/2 | sed 's#HTTP/2 ##g' | tr -d '[:space:]')

        sleep 30

        if [[ $UpdateCacheNodeResponse == 2** ]]
        then
                isProvisioningSucceeded $FqdrCacheNodeResourceUrl true

                if [[ $? == 1 ]]
                then
                        printDetailGreen "Successfully updated cache node $IotDeviceName"
                        break
                elif [[ $? == 2 && $CacheNodeUpdateMaxRetry != 0 ]]
                then
                        printWarning "Cache node resource provision state failed, retrying again"
                else
                        printError "Unable to update cache node $IotDeviceName. Please contact Microsoft, exiting"
                        exit 1
                fi
        elif [[ $CacheNodeUpdateMaxRetry == 0 ]]
        then
                printError "Unable to update cache node $IotDeviceName. Please contact Microsoft, exiting"
                exit 1
        fi
done

printDetailMagenta "Querying cache node for registration key. Please wait"

getRegKeyCount=0
while [[ -z $RegistrationKey ]]
do
        if [[ $getRegKeyCount == 30 ]]
        then
                printError "Get registration key timed out, exiting"
                exit 1
        fi

        RegistrationKeyResponse=$(curl -s -k -i GET "$CacheNodeResourceUrl&customerId=$CommandLineCustomerId&cacheNodeId=$CacheNodeId&cacheNodeName=$ResCacheNodeName&maxAllowableEgressInMbps=10000&isEnabled=True&isEnterprise=False&shouldMigrate=True" -H 'Content-Type: application/json' -H "Authorization: Bearer $AccessToken")
        RegistrationKey=$(echo $RegistrationKeyResponse | grep -Po '"RegistrationKey":.*?[^\\]"' | cut -d ":" -f2 | tr -d '[:space:]' | sed 's/\"//g')
        sleep 5
        ((getRegKeyCount++))
done

printDetailGreen "Successfully obtained registration key"

# set execute permissions on necessary scripts
chmod +x uninstallprivatepreview.sh
chmod +x ../provisionmcc.sh

printHeader "Uninstalling private preview on this host"

./uninstallprivatepreview.sh

if [[ $? == 0 ]]
then
        printDetailMagenta "Proceeding with public preview installation"
        curl https://packages.microsoft.com/config/ubuntu/20.04/prod.list > ./microsoft-prod.list
        sudo cp ./microsoft-prod.list /etc/apt/sources.list.d/
        sudo apt-get update

        cd ..
        ./provisionmcc.sh customerid="$CommandLineCustomerId" cachenodeid="$CacheNodeId" customerkey="$CustomerKey" registrationkey="$RegistrationKey" ismigrate="true"

        if [[ $? != 0 ]]
        then
                printError "Error migrating MCC private to public preview, exiting"
                exit 1
        fi            
else
        printError "Error uninstalling MCC private preview, exiting"
        exit 1
fi

printDetailGreen "Successfully migrated private preview to public preview"
exit 0