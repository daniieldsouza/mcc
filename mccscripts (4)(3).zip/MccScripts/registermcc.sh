#!/bin/bash
# define common functions
CLEAR=`tput sgr0`
BOLD=`tput bold`
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
CYAN=`tput setaf 6 `
WHITE=`tput setaf 7 `

function printHeader
{
	echo -n "${CYAN}${BOLD}$1${CLEAR}"
}

function printDetail
{
	echo -e "\n${WHITE}${BOLD}$1${CLEAR}\n"
}

function printDetailGreen
{
	echo -e "\n${GREEN}${BOLD}$1${CLEAR}\n"
}

function printDetailMagenta
{
	echo -e "\n${MAGENTA}${BOLD}$1${CLEAR}\n"
}

function printWarning
{
	echo -e "\n${YELLOW}${BOLD}$1${CLEAR}\n"
}

function printError
{
	echo -e "\n${RED}${BOLD}$1${CLEAR}\n"
}

function cleanString
{
	s="$1"

	# remove leading and trailing whitespace
	s="$(echo -e "${s}" | tr -d '[:space:]')"

	# remove leading and trailing slashes
	s=`echo "${s}" | sed -e "s/\/*$//" `
	s=`echo "${s}" | sed -e "s/^\///" `
}


# Read necessary info to deploy resources
printHeader "MCC Registration Script, Version : $ScriptVersion"

# Read input parameters from the command line and set relevant variables
for ARGUMENT in "$@"
do

	KEY=$(echo $ARGUMENT | cut -f1 -d:)
	VALUE=$(echo $ARGUMENT | cut -f2 -d:)

	case "$KEY" in
		customerid)					CommandLineCustomerId=${VALUE} ;;
		cachenodeid)				CommandLineCacheNodeId=${VALUE} ;;
		customerkey)				CommandLineCustomerKey=${VALUE} ;;
		registrationkey)			CommandLineRegistrationKey=${VALUE} ;;
		scopeid)					CommandLineScopeId=${VALUE};;
		primarykey)					CommandLinePrimaryKey=${VALUE};;
		*)			;;
	esac


done


# Get details specific to MCC configuration

if [ -z $CommandLineCustomerId ]; then
	printError "Azure Customer ID cannot be null, please ensure proper command line arguments are used, exiting "
	exit 1
fi

if [ -z $CommandLineCacheNodeId ]; then
	printError "Cache Node ID cannot be null, please ensure proper command line arguments are used, exiting "
	exit 1
fi

if [ -z $CommandLineCustomerKey ]; then
	printError "Customer Key cannot be null, please ensure proper command line arguments are used, exiting "
	exit 1
fi

if [ -z $CommandLineRegistrationKey ]; then
	printError "Customer Registration Key cannot be null, please ensure proper command line arguments are used, exiting "
	exit 1
fi



# copy TOML file over accounting for the different names
printDetailMagenta "Copying IoT Edge Configuration Template"
TemplateWithEdge=/etc/aziot/config.toml.edge.template
TemplateWithoutEdge=/etc/aziot/config.toml.template

if [ -f "$TemplateWithEdge" ]; then
	printDetailGreen "Found new edge template updating this version"
	cp /etc/aziot/config.toml.edge.template /etc/aziot/config.toml
elif [ -f "$TemplateWithoutEdge" ]; then
	printDetailGreen "Found default edge template"
	cp /etc/aziot/config.toml.template /etc/aziot/config.toml
else
	printError "Unable to find any IoTEdge Configuration Templates, exiting"
	exit 1
fi

# input our needed data
DpsTemplate=/etc/mccresourcecreation/dpsTemplate.txt

printDetailMagenta "Updating IoT Edge Configuration with Scope Id"
if [ -n "${CommandLineScopeId}" ]; then
	sed -i 's|<SCOPE_ID>|'$CommandLineScopeId'|g' $DpsTemplate
	printDetailGreen "Successfully updated Scope Id in IoT Edge Configuration"
else
	printError "Scope Id cannot be null, exiting"
	exit 1
fi

printDetailMagenta "Updating IoT Edge Configuration with Registration Id"
if [ -n "${CommandLineCacheNodeId}" ]; then
	sed -i 's|<DEVICE_ID>|'$CommandLineCacheNodeId'|g' $DpsTemplate
	printDetailGreen "Successfully updated Registration Id in IoT Edge Configuration"
else
	printError "Cache Node Id cannot be null, exiting"
	exit 1
fi

printDetailMagenta "Updating IoT Edge Configuration with Symmetric Key"
if [ -n "${CommandLinePrimaryKey}" ]; then
	sed -i 's|<SYMMERTRIC_KEY>|'$CommandLinePrimaryKey'|g' $DpsTemplate
	printDetailGreen "Successfully updated Symmertic Key in IoT Edge Configuration"
else
	printError "Symmetric cannot be null, exiting"
	exit 1
fi

# add dps registration to toml file
printDetailMagenta "Attempting to add configured properties to IoT Edge Configuration File"
sudo tee -a /etc/aziot/config.toml < /etc/mccresourcecreation/dpsTemplate.txt>/dev/null
printDetailGreen "Successfully set configuration properties"

# restart edge
printDetailMagenta "Applying IoT Edge configurations"
sudo iotedge config apply
printDetailGreen "Successfully applied configurations"

printDetailGreen "Successfully completed MCC device registration"

printDetailGreen "You have successfully provisioned your server and cache node installation process will begin. It could take up to 30 minutes for the cache node software to download and begin caching."
