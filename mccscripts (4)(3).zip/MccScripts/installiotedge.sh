#!/bin/bash
datetime="$(date +%Y_%m_%d__%H_%M_%S__%p)"
maxfiles="917504"
maxprocs="32768"

IsRedhat="false"

if [ -f "/etc/redhat-release" ];
then
	IsRedhat="true"
	RedhatVersion=$(cat /etc/redhat-release | grep -o '[0-9]\+\.[0-9]\+')
fi

# Check versioning passed in
if [[ $1 == *"1.4."* ]]; then
	echo "Edge Version Validated : "$1""
else
	echo "Invalid Edge Version , exiting : "$1""
	exit 1
fi

if [[ $2 == *"1.4."* ]]; then
	echo "Edge Identity Svc Version Validated : "$2""
else
	echo "Invalid Edge Identity Svc Version, exiting : "$2""
	exit 1
fi

# Backup the /etc/sysctl.conf
cp /etc/sysctl.conf "/etc/sysctl.conf.bak.mcc."$datetime""

# Backup the /etc/security/limits.conf
cp /etc/security/limits.conf "/etc/security/limits.conf.bak.mcc."$datetime""

# Backup the /etc/docker/daemon.json
cp /etc/docker/daemon.json "/etc/docker/daemon.json.bak.mcc."$datetime""

cp /etc/modules-load.d/modules.conf "/etc/modules-load.d/modules.conf.bak.mcc."$datetime""

if grep -q "tcp_bbr" "/etc/modules-load.d/modules.conf"; then
	echo "tcp_bbr found in /etc/modules-load.d/modules.conf"
else
	echo "tcp_bbr" >> /etc/modules-load.d/modules.conf
fi

if grep -q "nf_conntrack" "/etc/modules-load.d/modules.conf"; then
	echo "nf_conntrack found in /etc/modules-load.d/modules.conf"
else
	echo "nf_conntrack" >> /etc/modules-load.d/modules.conf
fi

# This value should be 1/4 of net.netfilter.nf_conntrack_max
cp /etc/modprobe.d/mcc_conntrack.conf "/etc/modprobe.d/mcc_conntrack.conf.bak.mcc."$datetime""
echo "options nf_conntrack hashsize=196608" > /etc/modprobe.d/mcc_conntrack.conf
 

# Backup the /etc/security/limits.conf
# Cannot write to /proc, so create /etc/mcc/proc/sys/net/core/
mkdir -p /etc/mcc/proc/sys/fs/
cp /proc/sys/fs/file-max "/etc/mcc/proc/sys/fs/file-max.bak.mcc."$datetime""
cp /proc/sys/fs/pipe-user-pages-soft "/etc/mcc/proc/sys/fs/pipe-user-pages-soft.bak.mcc."$datetime""
cp /proc/sys/fs/pipe-user-pages-hard "/etc/mcc/proc/sys/fs/pipe-user-pages-hard.bak.mcc."$datetime""


# SED does not work on empty files...
[[ -s /etc/sysctl.conf ]] || { [[ -f /etc/sysctl.conf ]] && echo " " > /etc/sysctl.conf || echo " " > /etc/sysctl.conf; }
[[ -s /etc/limits.conf ]] || { [[ -f /etc/limits.conf ]] && echo " " > /etc/limits.conf || echo " " > /etc/limits.conf; }
[[ -s /etc/security/limits.conf ]] || { [[ -f /etc/security/limits.conf ]] && echo " " > /etc/limits.conf || echo " " > /etc/security/limits.conf; }


# -------------- Update nofile --------------
# Update the  nofile (Backup any line not starting with #, add new entry to the end of the file)
sed -i -e '/.*#.*user.*hard.*nofile/! s/.*user.*hard.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t hard \t nofile\t '"$maxfiles"'' /etc/limits.conf
sed -i -e '/.*#.*user.*soft.*nofile/! s/.*user.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t soft \t nofile\t '"$maxfiles"'' /etc/limits.conf
sed -i -e '/.*#.*root.*hard.*nofile/! s/.*root.*hard.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t hard \t nofile\t '"$maxfiles"'' /etc/limits.conf
sed -i -e '/.*#.*root.*soft.*nofile/! s/.*root.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t soft \t nofile\t '"$maxfiles"'' /etc/limits.conf
sed -i -e '/.*#.*\*.*soft.*nofile/! s/.*\*.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nofile\t '"$maxfiles"'' /etc/limits.conf
sed -i -e '/.*#.*\*.*soft.*nofile/! s/.*\*.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nofile\t '"$maxfiles"'' /etc/limits.conf


# -------------- Update nofile --------------
# Update the  nofile (Backup any line not starting with #, add new entry to the end of the file)
sed -i -e '/.*#.*user.*hard.*nofile/! s/.*user.*hard.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t hard \t nofile\t '"$maxfiles"'' /etc/security/limits.conf
sed -i -e '/.*#.*user.*soft.*nofile/! s/.*user.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t soft \t nofile\t '"$maxfiles"'' /etc/security/limits.conf
sed -i -e '/.*#.*root.*hard.*nofile/! s/.*root.*hard.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t hard \t nofile\t '"$maxfiles"'' /etc/security/limits.conf
sed -i -e '/.*#.*root.*soft.*nofile/! s/.*root.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t soft \t nofile\t '"$maxfiles"'' /etc/security/limits.conf
sed -i -e '/.*#.*\*.*soft.*nofile/! s/.*\*.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nofile\t '"$maxfiles"'' /etc/security/limits.conf
sed -i -e '/.*#.*\*.*soft.*nofile/! s/.*\*.*soft.*nofile.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nofile\t '"$maxfiles"'' /etc/security/limits.conf


# -------------- Update nproc  --------------
# Update the  nproc  (Backup any line not starting with #, add new entry to the end of the file)
sed -i -e '/.*#.*user.*hard.*nproc/! s/.*user.*hard.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t hard \t nproc\t '"$maxprocs"'' /etc/limits.conf
sed -i -e '/.*#.*user.*soft.*nproc/! s/.*user.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t soft \t nproc\t '"$maxprocs"'' /etc/limits.conf
sed -i -e '/.*#.*root.*hard.*nproc/! s/.*root.*hard.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t hard \t nproc\t '"$maxprocs"'' /etc/limits.conf
sed -i -e '/.*#.*root.*soft.*nproc/! s/.*root.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t soft \t nproc\t '"$maxprocs"'' /etc/limits.conf
sed -i -e '/.*#.*\*.*soft.*nproc/! s/.*\*.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nproc\t '"$maxprocs"'' /etc/limits.conf
sed -i -e '/.*#.*\*.*soft.*nproc/! s/.*\*.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nproc\t '"$maxprocs"'' /etc/limits.conf


# -------------- Update nproc  --------------
# Update the  nproc  (Backup any line not starting with #, add new entry to the end of the file)
sed -i -e '/.*#.*user.*hard.*nproc/! s/.*user.*hard.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t hard \t nproc\t '"$maxprocs"'' /etc/security/limits.conf
sed -i -e '/.*#.*user.*soft.*nproc/! s/.*user.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$auser \t soft \t nproc\t '"$maxprocs"'' /etc/security/limits.conf
sed -i -e '/.*#.*root.*hard.*nproc/! s/.*root.*hard.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t hard \t nproc\t '"$maxprocs"'' /etc/security/limits.conf
sed -i -e '/.*#.*root.*soft.*nproc/! s/.*root.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$aroot \t soft \t nproc\t '"$maxprocs"'' /etc/security/limits.conf
sed -i -e '/.*#.*\*.*soft.*nproc/! s/.*\*.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nproc\t '"$maxprocs"'' /etc/security/limits.conf
sed -i -e '/.*#.*\*.*soft.*nproc/! s/.*\*.*soft.*nproc.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a\* \t soft \t nproc\t '"$maxprocs"'' /etc/security/limits.conf

if [ "$IsRedhat" = "false" ]; 
then
	# Changes related to /etc/pam.d/common-session and /etc/pam.d/common-session-noninteractive are applicable 
	# when the OS is Ubuntu only. Redhat handles this config differently and is already included by default.

	# Backup the /etc/pam.d/common-session
	cp /etc/pam.d/common-session "/etc/pam.d/common-session.bak.mcc."$datetime""

	# Backup the /etc/pam.d/common-session-noninteractive
	cp /etc/pam.d/common-session-noninteractive "/etc/pam.d/common-session-noninteractive.bak.mcc."$datetime""

	sed -i -e '/.*#.*session.*required.*pam_limits.so/! s/.*session.*required.*pam_limits.so.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$asession required pam_limits.so' /etc/pam.d/common-session
	sed -i -e '/.*#.*session.*required.*pam_limits.so/! s/.*session.*required.*pam_limits.so.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$asession required pam_limits.so' /etc/pam.d/common-session-noninteractive
fi


# the sysctl file cannot be empty for SED to work, so append a char
echo " " >> /etc/sysctl.conf

# (256)        * 1024 = 262144
# (1024 + 512) * 1024 = 1572864
# (1024 + 128) * 1024 = 1179648
# (1024 +  64) * 1024 = 1114112
# (1024 +  32) * 1024 = 1081344

# From IBM
# 	net.ipv4.tcp_rmem=4096 87380 16777216 

# MCCs use case is different
#    net.ipv4.tcp_rmem=4096 87380 524288        // Tuned for 5 meg slices, or no payload requests
#    net.ipv4.tcp_wmem=262144 1064960 2097152   // Tuned for the typical 1 meg chunk returned to the client

# Reached 35 Gbps - however, likely not required
#     "net.ipv4.tcp_rmem" "262144 4194304 67108864"
#     "net.ipv4.tcp_wmem" "1064960 4194304 67108864"

totalMem=$(awk '/MemTotal/ { printf "%.3f \n", $2/1024/1024 }' /proc/meminfo)
maxPages=$(echo "1024 * 1024 * 1024 * ${totalMem} * 1.00 / 4000" | bc)
highPages=$(echo "1024 * 1024 * 1024 * ${totalMem} * 0.20 / 4000" | bc)
medPages=$(echo "1024 * 1024 * 1024 * ${totalMem} * 0.10 / 4000" | bc)
lowPages=$(echo "1024 * 1024 * 1024 * ${totalMem} * 0.05 / 4000" | bc)

echo "TCP memory configuration"
echo "    Total Memory (GB): ${totalMem}"
echo "    Total   # 4k pages available: ${maxPages}"
echo "    High    # 4k pages available: ${highPages}"
echo "    Medium  # 4k pages available: ${medPages}"
echo "    Low     # 4k pages available: ${lowPages}"


sysctlParams=(
"vm.swappiness" "10"
"vm.dirty_ratio" "60"
"vm.dirty_background_ratio" "2"
"vm.zone_reclaim_mode" "0"
"net.netfilter.nf_conntrack_generic_timeout" "30"
"net.netfilter.nf_conntrack_icmp_timeout" "10"
"net.netfilter.nf_conntrack_tcp_timeout_time_wait" "30"
"net.netfilter.nf_conntrack_tcp_timeout_close" "10"
"net.netfilter.nf_conntrack_tcp_timeout_close_wait" "30"
"net.netfilter.nf_conntrack_tcp_timeout_established" "90"
"net.netfilter.nf_conntrack_tcp_timeout_fin_wait" "30"
"net.netfilter.nf_conntrack_tcp_timeout_last_ack" "30"
"net.netfilter.nf_conntrack_tcp_timeout_max_retrans" "30"
"net.netfilter.nf_conntrack_tcp_timeout_syn_recv" "30"
"net.netfilter.nf_conntrack_tcp_timeout_syn_sent" "30"
"net.netfilter.nf_conntrack_tcp_timeout_unacknowledged" "30"
"net.netfilter.nf_conntrack_udp_timeout" "30"
"net.netfilter.nf_conntrack_udp_timeout_stream" "30"
"net.netfilter.nf_conntrack_max" "786432"
"net.nf_conntrack_max" "786432"
"fs.file-max" "${maxfiles}"
"fs.pipe-max-size" "16777216"
"fs.pipe-user-pages-hard" "0"
"fs.pipe-user-pages-soft" "0"
"net.unix.max_dgram_qlen" "50"
"net.ipv4.neigh.default.gc_thresh1" "8192"
"net.ipv4.neigh.default.gc_thresh2" "12228"
"net.ipv4.neigh.default.gc_thresh3" "24456"
"net.ipv4.neigh.default.gc_interval" "30"
"net.ipv4.neigh.default.gc_stale_time" "60"
"net.ipv4.neigh.default.proxy_qlen" "96"
"net.ipv4.neigh.default.unres_qlen" "6"
"net.ipv4.conf.all.accept_source_route" "0"
"net.ipv4.conf.lo.accept_source_route" "0"
"net.ipv4.conf.eth0.accept_source_route" "0"
"net.ipv4.conf.default.accept_source_route" "0"
"net.ipv4.conf.all.accept_redirects" "0"
"net.ipv4.conf.all.secure_redirects" "0"
"net.ipv4.conf.all.send_redirects" "0"
"net.ipv4.conf.all.rp_filter" "1"
"net.ipv4.conf.lo.rp_filter" "1"
"net.ipv4.conf.eth0.rp_filter" "1"
"net.ipv4.conf.default.rp_filter" "1"
"net.ipv4.tcp_mtu_probing" "1"
"net.ipv4.tcp_congestion_control" "bbr"
"net.ipv4.tcp_max_orphans" "131072"
"net.ipv4.tcp_ecn" "1"
"net.ipv4.tcp_reordering" "3"
"net.ipv4.tcp_retries2" "15"
"net.ipv4.tcp_retries1" "3"
"net.ipv4.tcp_slow_start_after_idle" "0"
"net.ipv4.tcp_fastopen" "3"
"net.ipv4.tcp_max_tw_buckets" "1440000"
"net.ipv4.tcp_orphan_retries" "0"
"net.ipv4.tcp_fin_timeout" "10"
"net.ipv4.tcp_keepalive_time" "30"
"net.ipv4.tcp_keepalive_intvl" "15"
"net.ipv4.tcp_keepalive_probes" "5"
"net.ipv4.tcp_synack_retries" "2"
"net.ipv4.tcp_syncookies" "0"
"net.ipv4.tcp_sack" "1"
"net.ipv4.tcp_dsack" "1"
"net.ipv4.tcp_window_scaling" "1"
"net.ipv4.tcp_rfc1337" "1"
"net.ipv4.tcp_no_metrics_save" "1"
"net.ipv4.tcp_moderate_rcvbuf" "1"
"net.ipv4.tcp_tw_reuse" "1"
"net.ipv4.tcp_timestamps" "1"
"net.ipv4.tcp_mem" "${lowPages} ${medPages} ${highPages}"
"net.ipv4.tcp_rmem" "4096 87380 67108864"
"net.ipv4.tcp_wmem" "262144 1064960 67108864"
"net.ipv4.ip_local_port_range" "2048 65535"
"net.ipv4.ip_forward" "0"
"net.ipv4.ipfrag_high_thresh" "512000"
"net.ipv4.ipfrag_low_thresh" "446464"
"net.ipv4.icmp_echo_ignore_broadcasts" "1"
"net.ipv4.icmp_echo_ignore_all" "1"
"net.ipv4.icmp_ignore_bogus_error_responses" "1"
"net.ipv4.udp_rmem_min" "16384"
"net.ipv4.udp_wmem_min" "16384"
"net.ipv4.route.flush" "1"
"net.ipv6.route.flush" "1"
"net.ipv6.conf.all.autoconf" "0"
"net.ipv6.conf.all.accept_ra" "0"
"net.ipv6.conf.default.autoconf" "0"
"net.ipv6.conf.default.accept_ra" "0"
"net.ipv6.conf.eth0.autoconf" "0"
"net.ipv6.conf.eth0.accept_ra" "0"
"net.core.default_qdisc" "fq"
"net.core.somaxconn" "8192"
"net.ipv4.tcp_max_syn_backlog" "8192"
"net.core.net.dev_max_backlog" "32768"
"net.core.netdev_max_backlog" "32768"
"net.core.dev_weight" "64"
"net.core.optmem_max" "2048000"
"net.core.rmem_max" "67108864"
"net.core.wmem_max" "67108864")


# Update the /etc/sysctl.conf properties
for ((i=0; i < ${#sysctlParams[@]}; i++))
do
	key=${sysctlParams[$i]}
	i=$[i+1] 
	value=${sysctlParams[$i]}
	
	#echo "key =   " $key
	#echo "value = " $value
	
	sed -i -e '/.*#.*'"$key"'/! s/.*'"$key"'.*/#\0 \t#MCC backup ('"$datetime"')/' -e '$a'"$key"'='"$value"'' /etc/sysctl.conf
done


# reload all sysctl settings after the updates
sudo sysctl -p
sudo sysctl --system

if [ "$IsRedhat" = "false" ]; 
then
	apt-get install -y nano
	apt-get install -y curl

	# Set up SSH
	apt-get install -y openssh-client openssh-server
	sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/g' /etc/ssh/sshd_config
	service ssh restart

	wget https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
	sudo dpkg -i packages-microsoft-prod.deb
	rm packages-microsoft-prod.deb

	apt-get update -y
	apt-get install -y moby-engine
	apt-get install -y moby-cli
else
	yum install -y nano
	yum install -y curl

	# Set up SSH
	yum install -y openssh-clients openssh-server
	sed -i 's/#PasswordAuthentication yes/PasswordAuthentication yes/g' /etc/ssh/sshd_config
	systemctl restart sshd

	if [[ $RedhatVersion == 8.* ]];
	then
		wget https://packages.microsoft.com/config/rhel/8/packages-microsoft-prod.rpm -O packages-microsoft-prod.rpm
	elif [[ $RedhatVersion == 9.* ]];
	then
		wget https://packages.microsoft.com/config/rhel/9.0/packages-microsoft-prod.rpm -O packages-microsoft-prod.rpm
	fi

	sudo yum localinstall -y packages-microsoft-prod.rpm
	rm packages-microsoft-prod.rpm

	# RHEL latest version uses podman as the default container runtime and as such will not allow installing moby-engine and 
	# moby-cli due to conflicting dependencies. --allowerasing option is used to remove the conflicting dependencies to install docker
	yum install -y --allowerasing moby-engine moby-cli

	if [ ! -f "/etc/docker/" ];
	then
		mkdir /etc/docker
	fi
fi

echo "{" >  /etc/docker/daemon.json
echo "    \"log-driver\": \"json-file\", \"log-opts\": {\"max-size\": \"10m\",\"max-file\": \"3\"}" >>  /etc/docker/daemon.json
#echo "    \"dns\": [\"127.0.0.11\", \"8.8.8.8\", \"8.8.4.4\"]" >> /etc/docker/daemon.json
echo "}" >>  /etc/docker/daemon.json


systemctl restart docker

if [ "$IsRedhat" = "false" ]; 
then
	# Install IoT edge
	apt-get update -y
	apt-get install -y aziot-edge=$1 aziot-identity-service=$2 defender-iot-micro-agent-edge


	#*************************************************************
	#config
	#*************************************************************


	#open the ports required by iotedge
	ufw allow in 80
	ufw allow out 80
	ufw allow in 443
	ufw allow out 443
	ufw allow in 5671
	ufw allow out 5671
	ufw allow in 8883
	ufw allow out 8883
else
	# Installing specific iotedge version to avoid regression which might be part of latest releases. 
	if [[ $RedhatVersion == 8.* ]]; then
		yum install -y aziot-identity-service-$2.el8.x86_64 aziot-edge-$1.el8.x86_64
	elif [[ $RedhatVersion == 9.* ]]; then
		yum install -y aziot-identity-service-$2.el9.x86_64 aziot-edge-$1.el9.x86_64
	fi

	firewall-cmd --zone=public --add-port=80/tcp --permanent
	firewall-cmd --zone=public --add-port=443/tcp --permanent
	firewall-cmd --zone=public --add-port=5671/tcp --permanent
	firewall-cmd --zone=public --add-port=8883/tcp --permanent
	firewall-cmd --reload
fi

# -------------------------------------------------- Reference --------------------------------------------------


#Search for and set "device_connection_string" in /etc/iotedge/config.yaml
#cp /etc/iotedge/config.yaml ./config.yaml.backup
#nano /etc/iotedge/config.yaml


#Ensure the docker daemon DNS is configured
#nano /etc/docker/daemon.json
#{
#	"dns":["127.0.0.11 8.8.8.8 8.8.4.4"]
#}


#systemctl restart docker
#systemctl restart iotedge

#sysctl --system


#iotedge logs edgeAgent
#iotedge logs edgeHub


#iotedge check --verbose