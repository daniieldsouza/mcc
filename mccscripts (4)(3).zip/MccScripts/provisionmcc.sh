#!/bin/bash
ScriptVersion=1.03
CurrentPackageVersion=0

# default az iot package version aug 2023
DefaultAzIoTPackageVersion=1.4.16-1
DefaultAzIoTIdentitySvcPackageVersion=1.4.5-1

# define common functions
CLEAR=`tput sgr0`
BOLD=`tput bold`
RED=`tput setaf 1`
GREEN=`tput setaf 2`
YELLOW=`tput setaf 3`
MAGENTA=`tput setaf 5`
CYAN=`tput setaf 6 `
WHITE=`tput setaf 7 `

function printHeader
{
	echo -n "${CYAN}${BOLD}$1${CLEAR}"
}

function printDetail
{
	echo -e "\n${WHITE}${BOLD}$1${CLEAR}\n"
}

function printDetailGreen
{
	echo -e "\n${GREEN}${BOLD}$1${CLEAR}\n"
}

function printDetailMagenta
{
	echo -e "\n${MAGENTA}${BOLD}$1${CLEAR}\n"
}

function printWarning
{
	echo -e "\n${YELLOW}${BOLD}$1${CLEAR}\n"
}

function printError
{
	echo -e "\n${RED}${BOLD}$1${CLEAR}\n"
}

function printWarningPrompt
{
	echo -n "${YELLOW}${BOLD}$1${CLEAR}"
}

function cleanString
{
	s="$1"

	# remove leading and trailing whitespace
	s="$(echo -e "${s}" | tr -d '[:space:]')"

	# remove leading and trailing slashes
	s=`echo "${s}" | sed -e "s/\/*$//" `
	s=`echo "${s}" | sed -e "s/^\///" `
}

# Create log file and tee off all output to log
timestamp=$(date +%Y_%m_%d__%H_%M_%S__%p)
LOG_FILE=/etc/mccresourcecreation/installConnectedCacheLog_$timestamp.txt

exec > >(tee ${LOG_FILE}) 2>&1

printDetailGreen "Starting MCC Installer script. Version : $ScriptVersion"

# set execute permissions on necessary scripts
chmod +x installiotedge.sh
chmod +x registermcc.sh

printDetailMagenta "Checking to ensure that Ubuntu 20.04/Redhat 8 or 9 is being used"

IsRedhat="false"

if [ ! -f "/etc/redhat-release" ];
then
	UbuntuVersion=$(lsb_release -r | cut -d ':' -f2 | tr -d '[:space:]')
	if [[ $UbuntuVersion == 20.04 ]];
	then
	        printDetailGreen "Successfully verified that Ubuntu version is 20.04."
	else
	        printError "Current ubuntu version is $UbuntuVersion which is different from the recommended 20.04 version. Exiting."
	        exit 1
	fi
else
	RedhatVersion=$(cat /etc/redhat-release | grep -o '[0-9]\+\.[0-9]\+')
	if [[ $RedhatVersion == 8.* ]] || [[ $RedhatVersion == 9.* ]];
	then
		printDetailGreen "Successfully verified that Redhat version is $RedhatVersion."
		IsRedhat="true"

		printWarningPrompt "WARNING: As part of the installation, podman and its dependencies if any might be removed. Do you still want to proceed [Y/n]? : "
		read -r RemovePodman
		cleanString ${RemovePodman}

		if [ -z $RemovePodman ] || [ $RemovePodman == "y" ] || [ $RemovePodman == "Y" ]; 
		then
			printDetailGreen "Proceeding with installation."
		elif [ $RemovePodman == "n" ] || [ $RemovePodman == "N" ]; then
			printError "Installation cannot proceed without removing podman and its dependencies. Exiting."
	        	exit 1
	        else
			printError "Invalid input entered, please re-run script with valid input. Exiting"
			exit 1
	        fi
	else
		printError "Current Redhat version is $RedhatVersion which is different from the recommended 8 or 9 version. Exiting."
		exit 1
	fi
fi

# Check for iot edge config template
printDetailMagenta "Checking to ensure registration template file exists"
if [ ! -f "dpsTemplate.txt" ];
then
	printError "Plese re-run script at root directory where MCC registration files exist, exiting"
	exit 1
else
	printDetailGreen "Verified DPS template exists, running MCC registration scripts"
fi


# Get the latest package version from script resource directory
printDetailMagenta "Checking to ensure latest package version is running"
if [ ! -f "packageVer.txt" ];
then
	printError "Please ensure you are running the latest version of MCC scripts, exiting"
	exit 1
else
	CurrentPackageVersion=$(cat packageVer.txt)
	printDetail "Running package version : $CurrentPackageVersion"
fi

# Create MCC resource creation script resource directory
printDetailMagenta "Creating or checking from MCC temp directory"
if [ -d "/etc/mccresourcecreation/" ];
then
	printDetailGreen "MCC directory already exists, continuing"
else
	printDetailMagenta "MCC directory not detected, creating"
	mkdir /etc/mccresourcecreation/
	printDetailGreen "MCC directory successfully created"
fi

printDetailMagenta "Copying over necessary MCC template files"
cp dpsTemplate.txt /etc/mccresourcecreation/
printDetailGreen "Completed copying necessary MCC template files"

# set constant variable names
Https=https://
ToolName="/mccTool?toolName=deviceRegistration&"
OverrideToolName="/tool?toolName=doinc&"

# parse script arguements
# Read input parameters from the command line and set relevant variables
printDetailMagenta "Parsing command line arguements"
for ARGUMENT in "$@"
do

	KEY=$(echo $ARGUMENT | cut -f1 -d=)
	VALUE=$(echo $ARGUMENT | cut -f2 -d=)

	cleanString "${KEY}"
	KEY="${s}"
	cleanString "${VALUE}"
	VALUE="${s}"

	case "$KEY" in
		customerid)					CommandLineCustomerId=${VALUE} ;;
		cachenodeid)				CommandLineCacheNodeId=${VALUE} ;;
		customerkey)				CommandLineCustomerKey=${VALUE} ;;
		registrationkey)			CommandLineRegistrationKey=${VALUE} ;;
		drivepathandsizeingb)		CommandLineDrivePathAndSizeInGb=${VALUE} ;;
		ismigrate)					CommandLineIsMigrate=${VALUE} ;;
		*)			;;
	esac
done
printDetailGreen "Completed parsing relevant command line arguements"

# ensure necessary parameters are not null
if [ -z $CommandLineCustomerId ]; then
	printError "customerid cannot be null, please ensure proper command line arguments are used, exiting "
	exit 1
fi


if [ -z $CommandLineCacheNodeId ]; then
	printError "cachenodeid cannot be null, please ensure proper command line arguments are used, exiting"
	exit 1
fi


if [ -z $CommandLineCustomerKey ]; then
	printError "customerkey cannot be null, please ensure proper command line arguments are used, exiting"
	exit 1
fi

if [ -z $CommandLineRegistrationKey ]; then
	printError "registrationkey cannot be null, please ensure proper command line arguments are used, exiting"
	exit 1
fi

if [ -z $CommandLineIsMigrate ] && [ -z $CommandLineDrivePathAndSizeInGb ]; then
	printWarning "drivepathandsizeingb cannot be null, please ensure proper command line arguments are used"
fi

if [ -z $CommandLineIsMigrate ]; then

	# adding a leading slash as it is being removed during cleanString
	CommandLineDrivePathAndSizeInGb="/${CommandLineDrivePathAndSizeInGb}"
	old_ifs="$IFS"

	IFS=','

	read -ra PathSizeArray <<< "$CommandLineDrivePathAndSizeInGb"

	PathSizeArrayLength=${#PathSizeArray[@]}

	IFS="$old_ifs"

	if [ $PathSizeArrayLength -le 1 ]; then
		printWarning "Cache drive path is null in portal. Please go to the Azure portal to enter the value."
	else
		printDetailMagenta "Validating cache directory path and size"

		Index=0

		while [ $Index -lt $PathSizeArrayLength ]
		do
			CachePath=${PathSizeArray[$Index]}
			CacheSize=${PathSizeArray[$Index+1]}

			printDetail "Validating cache directory path : $CachePath and cache size : $CacheSize"

			if [ "$CachePath" == "" ] || [ "$CachePath" == "/" ]; then
				printError "Invalid directory path entered, please try again. Exiting"
				exit 1
			fi

			CachePathLastChar=$(echo "${CachePath: -1}")
			if [ $CachePathLastChar == "/" ]; then
				printDetailMagenta "Checking for directory existence"
			else
				printWarning "Appending / to check if specified directory exists"
				CachePath+="/"
			fi

			if ! [ -d "$CachePath" ]; then
				printError "Cache folder not created in ubuntu: Cannot find the cache folder on your server. Please create the folder as entered in the Azure portal and try again. Exiting"
				exit 1
			else
				printDetailGreen "Directory path $CachePath exists, and will be used for MCC cache folder"

				# get total number of files/folders in the input location
				LevelCount=$(ls $CachePath | wc -l)
				if [ $LevelCount == 0 ]; then
					# set permissions to everyone read / write 
					chmod -R 777 "$CachePath"
				else
					# change permission for input path only
					chmod 777 "$CachePath"
					# regex to obtain folders whose names have a single character a-z or 0-9
					# and change permission only on those folders
					files=$(ls -l $CachePath | grep -Po "^d.* [a-z0-9]$" | grep -Po "[a-z0-9]$")
					for file in $files;
					do 
						chmod -R 777 "$CachePath$file/"
					done
				fi
			fi
			
			ActualSpace=$(df -m "$CachePath" | awk '{print $2}' | awk 'FNR == 2 {print}')
			ActualSpace=$(( $ActualSpace/1000 ))

			if [ $ActualSpace -lt $CacheSize ]; then
				printError "Specified amount of space does not exist on $CachePath. Available space is $ActualSpace GB and specified space is $CacheSize GB. Please update the space in portal and try again. Exiting"
				exit 1
			else
				printDetailGreen "Successfully validated that $CacheSize GB space is available in $CachePath"
			fi

			Index=$(( $Index + 2 ))
		done
		printDetailGreen "Successfully validated cache drive path and size"
	fi
fi

if [ "$IsRedhat" = "false" ]; 
then
	apt-get install -y curl
else
	yum install -y curl
fi


printDetailMagenta "Calling to retrieve registration endpoint"
GeoResponse=$(curl --insecure -i 'https://geomcc.prod.do.dsp.mp.microsoft.com/geo')
KvEndpointUrl=$( echo $GeoResponse | grep -Po '"KeyValue_EndpointFullUri":.*?[^\\]",' | tr "," "\n"  | cut -d "\"" -f4 | cut -d "/" -f3)
printDetailGreen "Successfully called to retrieve registration endpoint"

printDetailMagenta "Attemtpting to retrieve latest package version"
DoincCustomerId="doincCustomerId=${CommandLineCustomerId}"
DoincCustomerKey="&doincCustomerKey=${CommandLinePrimaryKey}"
KvVersionUri="${Https}${KvEndpointUrl}${OverrideToolName}${DoincCustomerId}${DoincCustomerKey}"
KvOverrideResponse=$(curl -i ${KvVersionUri})
printDetailGreen "Successfully retrieved latest package"

AllowedPackageVersion=$(echo $KvOverrideResponse | grep -Po '"MccInstallerPackage_Target_Version":.*?[^\\]"' | cut -d '"' -f4)
if [ -z $AllowedPackageVersion ]; then
	printError "Unable to parse the latest package version from overrides, please re-run script, exiting"
	exit 1
else
	printDetailGreen "Retrieved override for allowed version : $AllowedPackageVersion"
fi

printDetailMagenta "Verifying that the latest Mcc Registration scripts are being used"
if [ $CurrentPackageVersion == $AllowedPackageVersion ]; then
	printDetailGreen "Latest package version is being used. Version : $CurrentPackageVersion"
else
	printError "Latest package version is not being used, please download latest pacakage from Azure portal. Current Version : $CurrentPackageVersion. Latest Available Version : $AllowedPackageVersion"
	exit 1
fi

# Obtain the proper AzIot-Edge package versions to use during installation 
AzIoTPackageVersion=$(echo $KvOverrideResponse | grep -Po '"MccInstallerPackage_AzIoTEdge_Target_Version":.*?[^\\]"' | cut -d '"' -f4)
AzIoTIdentitySvcPackageVersion=$(echo $KvOverrideResponse | grep -Po '"MccInstallerPackage_AzIoTEdge_IdentitySvc_Target_Version":.*?[^\\]"' | cut -d '"' -f4)

if [ -z $AzIoTPackageVersion ]; then
	printError "Unable to parse the latest AzIoT package version for install, using default version : $DefaultAzIoTPackageVersion"
	AzIoTPackageVersion=$DefaultAzIoTPackageVersion
else
	printDetailGreen "Retrieved latest AzIoT package version : $AzIoTPackageVersion"
fi

if [ -z $AzIoTIdentitySvcPackageVersion ]; then
	printError "Unable to parse the latest AzIoT Identity Service package version for install, using default version : $DefaultAzIoTIdentitySvcPackageVersion"
	AzIoTIdentitySvcPackageVersion=$DefaultAzIoTIdentitySvcPackageVersion
else
	printDetailGreen "Retrieved latest AzIoT Identity Service package version : $AzIoTIdentitySvcPackageVersion"
fi

# Call KeyValue and attempt to get registration details from mccTool handler
printDetailMagenta "Attempting to retrieve MCC device registration details"
CustomerKey="customerKey=${CommandLineCustomerKey}"
CustomerId="&customerId=${CommandLineCustomerId}"
CacheNodeId="&cacheNodeId=${CommandLineCacheNodeId}"
RegistrationKey="&registrationKey=${CommandLineRegistrationKey}"

FinalKvToolUri="${Https}${KvEndpointUrl}${ToolName}${CustomerKey}${CustomerId}${CacheNodeId}${RegistrationKey}"
KvMccToolResponse=$(curl -i ${FinalKvToolUri})
IsValidCustomer=$(echo $KvMccToolResponse | grep -Po '"IsValidCustomer":.*?[^\\]"' | cut -d '"' -f4)
printDetailGreen "Successfully queried for MCC registration details"

if [ "$IsValidCustomer" == "true" ];
	then
	# If this is a valid customer, then parse registration info
	ScopeIdParsed=$( echo $KvMccToolResponse | grep -Po '"scopeId":.*?[^\\]"' | cut -d '"' -f4)
	PrimaryKeyParsed=$(echo $KvMccToolResponse | grep -Po '"primaryKey":.*?[^\\]"' | cut -d '"' -f4)
else
	CommandLineCustomerId=`echo "${CommandLineCustomerId}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
	CommandLineCustomerKey=`echo "${CommandLineCustomerKey}" | sed -e "s/\(.*\)\(....\)/********************************\2/"`
	printError "The customer Id and cusotmer key are either invalid or not entitled. Please verify that the cusotmer Id and customer key match the values in the portal \n
	CustomerId:\t\t ${CommandLineCustomerId} \n
	CustomerKey:\t\t ${CommandLineCustomerKey} \n Exiting"
	exit 1
fi

printDetailMagenta "Verifying that MCC registration details were successfully parsed"
if [ -z "${ScopeIdParsed}" ] || [ -z "${PrimaryKeyParsed}" ]; then
	printError "The registration key is no longer valid, please visit the Azure portal for a new command line"
	exit 1
else
	printDetailGreen "Successfully parsed MCC registration details details"
fi

# Run configuration scripts
./installiotedge.sh $AzIoTPackageVersion $AzIoTIdentitySvcPackageVersion
./registermcc.sh "customerid:${CommandLineCustomerId}" "cachenodeid:${CommandLineCacheNodeId}" "customerkey:${CommandLineCustomerKey}" "registrationkey:${CommandLineRegistrationKey}" " scopeid:${ScopeIdParsed}" " primarykey:${PrimaryKeyParsed}"
